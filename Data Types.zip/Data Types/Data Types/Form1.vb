﻿Public Class DataTypeForm

    Private Sub NumericButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericButton.Click
        'Here we create two numeric variables:
        'The first is a Long number, the second is an Integer number
        Dim longNumber As Long
        Dim integerNumber As Integer

        'Here we assign values to our numeric variables
        longNumber = 1234567890
        integerNumber = 1234

        'Here we will pop-up two windows:
        'The first with our Long number, the second with our Integer number
        'The '&' character just 'adds' the number to our message.
        MsgBox("longNumber: " & longNumber)
        MsgBox("integerNumber: " & integerNumber)
    End Sub

    Private Sub CharButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CharButton.Click
        'Here we create two character variables
        'The first is a Char, which holds just a single character or letter
        'The second is a String, which can hold one or more characters or letters
        Dim myChar As Char
        Dim myString As String

        'Here we assign a value to our character variables
        myChar = "A"
        myString = "This is my string"

        'Here we will pop-up two windows:
        'The first with our Char, the second with our String
        'The '&' character just 'adds' the variable to our message.
        MsgBox("myChar: " & myChar)
        MsgBox("myString: " & myString)
    End Sub

    Private Sub BoolButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BoolButton.Click
        'Here we create a single Boolean (true or false) variable
        Dim myBoolean As Boolean

        'We set the value to 'true'
        myBoolean = True

        'Here we pop-up a window that will tell the user our true/false value
        MsgBox("myBoolean: " & myBoolean)
    End Sub
End Class
