﻿Imports System.Threading.Thread

Public Class ChainForm

    ' determine how many rows and columns we want in our grid
    Const NUM_ROWS As Integer = 5
    Const NUM_COLUMNS As Integer = 5

    ' cellSize will store the square cell size
    Dim cellSize As Integer

    ' each cell may be owned by nobody, player1, or player2
    Private Enum PLAYER
        NONE = 0
        PLAYER1 = 1
        PLAYER2 = 2
    End Enum

    ' these variables provide description and colors for each player
    Dim player1Description As String = "Player 1"
    Dim player2Description As String = "Player 2"
    Dim player1Color As Color = Color.Blue
    Dim player2Color As Color = Color.Red

    ' the Cell structure represents everything you need to know about a cell
    ' (sprite, which player owns the cell, and how much mass is in the cell)
    Private Structure Cell
        Dim mySprite As Sprite
        Dim owningPlayer As Integer
        Dim numDots As Integer
    End Structure

    ' the gamestate consists of an array of Cells and variable storing the current player turn
    Private Structure GameState
        Dim cellArray(,) As Cell
        Dim currentPlayer As PLAYER
    End Structure

    ' declare the global GameState variable to track our game
    Dim myGameState As GameState

    ' this flag will show if the game has been won or is still going
    Dim gameOver As Boolean

    ' This method provided complete in the Activity Starter
    Private Sub ChainForm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        ' when the form loads, start a new game
        StartGame()
    End Sub

    ' This method will be completed by the student in a Your Turn activity 
    Private Sub StartGame()
        ' begin a new game
        ReDim myGameState.cellArray(NUM_COLUMNS - 1, NUM_ROWS - 1)

        If (Me.ClientSize.Height > Me.ClientSize.Width) Then
            cellSize = (Me.ClientSize.Width / NUM_ROWS) - 10
        Else
            cellSize = (Me.ClientSize.Height / NUM_ROWS) - 10
        End If

        gameOver = False
        myGameState.currentPlayer = PLAYER.PLAYER1
        TurnLabel.Text = player1Description
        TurnLabel.ForeColor = player1Color

        InitializeGameGrid()
        Invalidate()

    End Sub

    ' This method will be completed by the student in a Your Turn activity 
    Private Sub InitializeGameGrid()
        ' Use a double For loop to loop through the two-dimensional cellArray
        For i = 0 To NUM_COLUMNS - 1
            For j = 0 To NUM_ROWS - 1
                myGameState.cellArray(i, j).owningPlayer = PLAYER.NONE
                myGameState.cellArray(i, j).numDots = 0
                myGameState.cellArray(i, j).mySprite = New Sprite
                myGameState.cellArray(i, j).mySprite.Size.X = cellSize
                myGameState.cellArray(i, j).mySprite.Size.Y = cellSize
                ' + 5 to upper left point offsets sprite from the cell edge a bit 
                myGameState.cellArray(i, j).mySprite.UpperLeft.X = i * cellSize + 5
                myGameState.cellArray(i, j).mySprite.UpperLeft.Y = j * cellSize + 5
                'Our cells are always 'alive' 
                myGameState.cellArray(i, j).mySprite.IsAlive = True

            Next
        Next
    End Sub


    ' This method provided complete in the Activity Starter
    Private Sub ChainForm_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles Me.Paint

        Dim myGraphics As Graphics = e.Graphics 'create the Graphics object that we will use to draw on the screen

        Dim gridPen As Pen = New Pen(Color.Black, 2) ' we will draw grid lines with black pen, width 2

        'This pen will be used to draw the player 1 circles on the screen
        Dim player1Pen As Pen = New Pen(Color.Blue, 4)

        'This brush will be used to fill in the player 2 dots on the screen
        Dim player2Brush As Brush = Brushes.Red

        ' Use a double For loop to loop through the two-dimensional cellArray
        For i = 0 To NUM_COLUMNS - 1
            For j = 0 To NUM_ROWS - 1

                ' make sure the sprite has been initialized correctly
                If (myGameState.cellArray(i, j).mySprite Is Nothing) Then
                    Continue For ' if no sprite, then continue with the next loop immediately
                End If

                ' get bounding rectangle for the sprite and draw the cell square
                Dim cellRect As Rectangle = myGameState.cellArray(i, j).mySprite.GetBoundingRectangle()
                myGraphics.DrawRectangle(gridPen, cellRect)

                ' if there is anything in the cell
                If (myGameState.cellArray(i, j).numDots > 0) Then

                    'Set a temporary variable with the value of the cell's Size
                    Dim cellSize As Point = myGameState.cellArray(i, j).mySprite.Size

                    'Calculate the size of our dots
                    Dim dotSize = cellSize.X \ 2 - 2

                    'Set a temporary variable with the value of the cell's bounding rectangle
                    Dim cellBounds = myGameState.cellArray(i, j).mySprite.GetBoundingRectangle()

                    ' get the number of dots in this cell
                    Dim numDots As Integer = myGameState.cellArray(i, j).numDots

                    If myGameState.cellArray(i, j).owningPlayer = PLAYER.PLAYER1 Then
                        'This Select statement will decide if we need to draw 1, 2, 3, or 4 circles in the cell
                        Select Case (numDots)
                            Case 1
                                myGraphics.DrawEllipse(player1Pen, cellBounds.Left + 2, cellBounds.Top + 2, dotSize, dotSize)
                            Case 2
                                myGraphics.DrawEllipse(player1Pen, cellBounds.Left + 2, cellBounds.Top + 2, dotSize, dotSize)
                                myGraphics.DrawEllipse(player1Pen, cellBounds.Right - dotSize - 2, cellBounds.Bottom - dotSize - 2, dotSize, dotSize)
                            Case 3
                                myGraphics.DrawEllipse(player1Pen, cellBounds.Left + 2, cellBounds.Top + 2, dotSize, dotSize)
                                myGraphics.DrawEllipse(player1Pen, cellBounds.Right - dotSize - 2, cellBounds.Bottom - dotSize - 2, dotSize, dotSize)
                                myGraphics.DrawEllipse(player1Pen, cellBounds.Left + 2, cellBounds.Bottom - dotSize - 2, dotSize, dotSize)
                            Case 4
                                myGraphics.DrawEllipse(player1Pen, cellBounds.Left + 2, cellBounds.Top + 2, dotSize, dotSize)
                                myGraphics.DrawEllipse(player1Pen, cellBounds.Right - dotSize - 2, cellBounds.Bottom - dotSize - 2, dotSize, dotSize)
                                myGraphics.DrawEllipse(player1Pen, cellBounds.Left + 2, cellBounds.Bottom - dotSize - 2, dotSize, dotSize)
                                myGraphics.DrawEllipse(player1Pen, cellBounds.Right - dotSize - 2, cellBounds.Top + 2, dotSize, dotSize)

                        End Select
                    Else
                        'This Select statement will decide if we need to draw 1, 2, 3, or 4 dots in the cell
                        Select Case (numDots)
                            Case 1
                                myGraphics.FillEllipse(player2Brush, cellBounds.Left + 2, cellBounds.Top + 2, dotSize, dotSize)
                            Case 2
                                myGraphics.FillEllipse(player2Brush, cellBounds.Left + 2, cellBounds.Top + 2, dotSize, dotSize)
                                myGraphics.FillEllipse(player2Brush, cellBounds.Right - dotSize - 2, cellBounds.Bottom - dotSize - 2, dotSize, dotSize)
                            Case 3
                                myGraphics.FillEllipse(player2Brush, cellBounds.Left + 2, cellBounds.Top + 2, dotSize, dotSize)
                                myGraphics.FillEllipse(player2Brush, cellBounds.Right - dotSize - 2, cellBounds.Bottom - dotSize - 2, dotSize, dotSize)
                                myGraphics.FillEllipse(player2Brush, cellBounds.Left + 2, cellBounds.Bottom - dotSize - 2, dotSize, dotSize)
                            Case 4
                                myGraphics.FillEllipse(player2Brush, cellBounds.Left + 2, cellBounds.Top + 2, dotSize, dotSize)
                                myGraphics.FillEllipse(player2Brush, cellBounds.Right - dotSize - 2, cellBounds.Bottom - dotSize - 2, dotSize, dotSize)
                                myGraphics.FillEllipse(player2Brush, cellBounds.Left + 2, cellBounds.Bottom - dotSize - 2, dotSize, dotSize)
                                myGraphics.FillEllipse(player2Brush, cellBounds.Right - dotSize - 2, cellBounds.Top + 2, dotSize, dotSize)

                        End Select

                    End If
                End If

            Next
        Next

    End Sub

    ' This method will be completed by the student in a Your Turn activity 
    Private Sub ChainForm_MouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Me.MouseClick

        For i = 0 To NUM_COLUMNS - 1
            For j = 0 To NUM_ROWS - 1
                ' if this sprite was clicked 
                If (myGameState.cellArray(i, j).mySprite.IsClicked(e.Location)) Then
                    ' If the current player already owns this cell, or nobody yet owns it 
                    If (myGameState.cellArray(i, j).owningPlayer = myGameState.currentPlayer) Or
                (myGameState.cellArray(i, j).owningPlayer = PLAYER.NONE) Then
                        ' Increase the mass in the cell and assign the owning player 
                        myGameState.cellArray(i, j).numDots += 1
                        myGameState.cellArray(i, j).owningPlayer = myGameState.currentPlayer
                        HandleExplosions()
                        If gameOver = True Then
                            StartGame()
                            Return
                        End If
                        If (myGameState.currentPlayer = PLAYER.PLAYER1) Then
                            myGameState.currentPlayer = PLAYER.PLAYER2
                            TurnLabel.Text = player2Description
                            TurnLabel.ForeColor = player2Color
                        Else
                            myGameState.currentPlayer = PLAYER.PLAYER1
                            TurnLabel.Text = player1Description
                            TurnLabel.ForeColor = player1Color
                        End If 'Refresh the screen 
                        Invalidate()
                    Else   ' If this is not our cell, we can't add a dot here 
                        MsgBox("That square is taken, try another!")
                    End If
                End If

            Next
        Next


    End Sub

    ' This method will be completed by the student in a Your Turn activity 
    Private Sub HandleExplosions()
        'Create a variable that will test to see if any cell needed to explode
        Dim isExploded As Boolean

        'Create a Do Loop that will always execute at least once
        Do
            isExploded = False  'initially, we will assume there aren't any explosions

            
        Loop While isExploded = True    'Continue this loop until there are no more explosions in the grid

    End Sub

    ' This method will be completed by the student in a Your Turn activity 
    Private Function CheckExplosion(ByVal ColNum As Integer, ByVal RowNum As Integer) As Boolean

        ' This function will check a cell to see if it contains enough dots to explode and, if so,
        ' determine which directions the explosion will go.

        ' Initialize a variable to the amount of mass needed in the cell to cause an explosion
        Dim dotsToExplode As Integer = 4

        ' declare flags indicating which ways the explosions will go
        Dim Up, Down, Left, Right As Boolean


    End Function

    ' This method will be completed by the student in a Your Turn activity 
    Private Sub Explode(ByVal ColNum As Integer, ByVal RowNum As Integer, ByVal Up As Boolean, ByVal Down As Boolean, ByVal Left As Boolean, ByVal Right As Boolean)


    End Sub


    ' This method will be completed by the student in a Your Turn activity 
    Private Sub CheckForWinner()

        ' there is a winner if there are no cells left owned by player1 or player2
        Dim player1Alive, player2Alive As Boolean


    End Sub


    ' This method will be completed by the student in a Your Turn activity 
    Private Sub StopGame(ByVal winningPlayer As PLAYER)


    End Sub
End Class
