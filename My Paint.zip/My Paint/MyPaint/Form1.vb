﻿'Include the drawing libraries that we will use to draw our shapes
Imports System.Drawing
Imports System.Drawing.Drawing2D

Public Class PaintForm
    'Create a starting point and an ending point
    'These will be used to draw the shapes
    Dim startingPoint As Point
    Dim endingPoint As Point

    'Declare a variable that will be use to hold the upper-left coordinates
    ' of the shape, as well as the height and width of the shape.
    Dim drawingRect As Rectangle

    ' This method provided complete in the Activity Starter
    Private Sub PaintForm_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Me.MouseDown

        'We will set our starting point to be the point where the user
        'has clicked down on the form
        startingPoint.X = e.X
        startingPoint.Y = e.Y

        'Place the value of our startingPoint into the drawingRect's Location property
        'This is the upper-left coordinate for our shape
        drawingRect.Location = startingPoint

    End Sub

    ' This method provided complete in the Activity Starter
    Private Sub PaintForm_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Me.MouseMove

        'When this event fires (every time the mouse moves) we will check to see
        'if the left button is being held down while the mouse is moving
        'If it is not, then we are not drawing a shape and we can leave this Sub
        If e.Button <> Windows.Forms.MouseButtons.Left Then
            Exit Sub
        End If

        'Update the endingPoint value with the current X and Y position of the mouse
        endingPoint.X = e.X
        endingPoint.Y = e.Y

        'Update the width and height of our shape by taking the difference between
        'the starting and ending points
        drawingRect.Width = endingPoint.X - startingPoint.X
        drawingRect.Height = endingPoint.Y - startingPoint.Y

        'Finally, we call the Invalidate function which will re-draw the screen
        Invalidate()
    End Sub

    ' Most of this method provided complete in the Activity Starter
    ' Part of this method will be completed by the student in the Activity
    Private Sub PaintForm_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles Me.Paint

        'Get the form's Graphics object to handle the drawing functions
        Dim myGraphics As Graphics = e.Graphics

        'Create a blue pen that has a width of 1 pixel
        Dim myPen As Pen = New Pen(Color.Blue, 1)

        'Create a pink solid brush
        Dim mySolidBrush = New SolidBrush(Color.Pink)

        'Create a gradient brush that will blend the colors yellow and blue
        'The colors will blend horizontally 
        Dim myGradientBrush = New LinearGradientBrush(New Rectangle(0, 0, Me.ClientSize.Width, Me.ClientSize.Height), Color.Blue, Color.Yellow, LinearGradientMode.Horizontal)

        'Here we check to see which radio button is selected (only one can be selected at a time)
        'This will tell us what shape to draw

        'If the ellipse is selected, draw the ellipse outline with myPen
        If EllipseRadio.Checked = True Then
            myGraphics.DrawEllipse(myPen, drawingRect)

            'If the filled ellipse is selected, draw the ellipse filled in with mySolidBrush
        ElseIf FilledEllipseRadio.Checked = True Then
            myGraphics.FillEllipse(mySolidBrush, drawingRect)

            'If the rectangle is selected, draw the rectangle outline with myPen
        ElseIf RectangleRadio.Checked = True Then
            myGraphics.DrawRectangle(myPen, drawingRect)

            'The user wants to draw a rectangle that is filled with a gradient color mix
        ElseIf GradientRectangleRadio.Checked = True Then
            myGraphics.FillRectangle(myGradientBrush, drawingRect)

            'The user wants to draw a line
        ElseIf LineRadio.Checked = True Then
            myGraphics.DrawLine(myPen, startingPoint, endingPoint)

        End If

    End Sub

    Private Sub PaintForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
