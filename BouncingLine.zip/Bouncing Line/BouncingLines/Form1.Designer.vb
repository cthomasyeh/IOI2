﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class BounceForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.LineTimer = New System.Windows.Forms.Timer(Me.components)
        Me.ShapeContainer1 = New Microsoft.VisualBasic.PowerPacks.ShapeContainer
        Me.BouncingLine = New Microsoft.VisualBasic.PowerPacks.LineShape
        Me.StartButton = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'LineTimer
        '
        '
        'ShapeContainer1
        '
        Me.ShapeContainer1.Location = New System.Drawing.Point(0, 0)
        Me.ShapeContainer1.Margin = New System.Windows.Forms.Padding(0)
        Me.ShapeContainer1.Name = "ShapeContainer1"
        Me.ShapeContainer1.Shapes.AddRange(New Microsoft.VisualBasic.PowerPacks.Shape() {Me.BouncingLine})
        Me.ShapeContainer1.Size = New System.Drawing.Size(431, 280)
        Me.ShapeContainer1.TabIndex = 0
        Me.ShapeContainer1.TabStop = False
        '
        'BouncingLine
        '
        Me.BouncingLine.Name = "BouncingLine"
        Me.BouncingLine.X1 = 123
        Me.BouncingLine.X2 = 241
        Me.BouncingLine.Y1 = 84
        Me.BouncingLine.Y2 = 122
        '
        'StartButton
        '
        Me.StartButton.Location = New System.Drawing.Point(12, 243)
        Me.StartButton.Name = "StartButton"
        Me.StartButton.Size = New System.Drawing.Size(75, 23)
        Me.StartButton.TabIndex = 1
        Me.StartButton.Text = "Start"
        Me.StartButton.UseVisualStyleBackColor = True
        '
        'BounceForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(431, 280)
        Me.Controls.Add(Me.StartButton)
        Me.Controls.Add(Me.ShapeContainer1)
        Me.Name = "BounceForm"
        Me.Text = "Bouncing Lines"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents LineTimer As System.Windows.Forms.Timer
    Friend WithEvents ShapeContainer1 As Microsoft.VisualBasic.PowerPacks.ShapeContainer
    Friend WithEvents BouncingLine As Microsoft.VisualBasic.PowerPacks.LineShape
    Friend WithEvents StartButton As System.Windows.Forms.Button

End Class
