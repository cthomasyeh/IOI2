﻿Imports System.Drawing
Imports System.Drawing.Imaging
Imports System.Drawing.Drawing2D
Imports Ice_Cream_Toss.Sprite

Public Class IceCreamForm
    'Create the four sprites that we will need for this program
    Dim scoopShot As Sprite
    Dim cannonBarrel As Sprite
    Dim iceCreamCone As Sprite
    Dim iceCreamConeTop As Sprite
    Dim cannonWheel As Sprite

    'This is the point at which we start our shot
    Dim shootingPoint As Point

    'Create a variable to hold the scoop shot's velocity
    Dim velocity As Double

    'We will use this to see if the user is pressing the spacebar key
    Dim isSpacePressed As Boolean

    'We will use this integer to keep track of the hits in our cone
    Dim iNumHits As Integer = 0

    Dim currentWind As Double = 0.0


    ' This method provided complete in the Activity Starter
    Private Sub IceCreamForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'When the form loads, call the StartGame function
        StartGame()
    End Sub

    ' This method provided complete in the Activity Starter
    Private Sub StartGame()

        ' initialize all of the shots' size, speed, and acceleration in advance
        scoopShot = New Sprite()
        scoopShot.Size = New Point(20, 20)
        scoopShot.IsAlive = False        ' no shots are initially alive
        scoopShot.TimeToLive = 30


        'Initialize the ice cream cannon barrel's sprite information
        cannonBarrel = New Sprite()
        cannonBarrel.IsAlive = True
        cannonBarrel.TimeToLive = -1
        cannonBarrel.UpperLeft = (New Point(10, Me.ClientSize.Height - 75))
        cannonBarrel.SetImageResource(My.Resources.cannon_barrel)
        cannonBarrel.Size = New Point(cannonBarrel.loadedImage.Width, cannonBarrel.loadedImage.Height)

        'Initialize the ice cream cone top's sprite information
        iceCreamConeTop = New Sprite()
        iceCreamConeTop.IsAlive = True
        iceCreamConeTop.TimeToLive = -1
        iceCreamConeTop.UpperLeft = (New Point(Me.ClientSize.Width - 85, Me.ClientSize.Height - 100))
        iceCreamConeTop.SetImageResource(My.Resources.cone_top)
        iceCreamConeTop.Size = New Point(My.Resources.cone_top.Width, My.Resources.cone_top.Height)

        'Initialize the ice cream cone's sprite information
        iceCreamCone = New Sprite()
        iceCreamCone.IsAlive = True
        iceCreamCone.TimeToLive = -1
        iceCreamCone.UpperLeft = (New Point(Me.ClientSize.Width - 85, Me.ClientSize.Height - 80))
        iceCreamCone.SetImageResource(My.Resources.cone_bottom)
        iceCreamCone.Size = New Point(My.Resources.cone_bottom.Width, My.Resources.cone_bottom.Height)

        'Initialize the cannon wheel's sprite information
        cannonWheel = New Sprite()
        cannonWheel.IsAlive = True
        cannonWheel.TimeToLive = -1
        cannonWheel.UpperLeft = (New Point(60, Me.ClientSize.Height - 65))
        cannonWheel.SetImageResource(My.Resources.cannon_wheel)
        cannonWheel.Size = New Point(My.Resources.cannon_wheel.Width, My.Resources.cannon_wheel.Height)

        CalculateWind() ' This function will calculate an initial wind value for the game

        'Start the timer
        TossTimer.Start()
    End Sub

    ' This method provided complete in the Activity Starter
    Private Sub IceCreamForm_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown

        'If the user is pressing the left arrow key
        If e.KeyCode = Keys.Left Then
            'If we are not pointing straight up
            If cannonBarrel.Angle < 90 Then
                'rotate backwards (counter-clockwise)
                cannonBarrel.ChangeAngle(1)
            End If

            'If the user is pressing the right arrow key
        ElseIf e.KeyCode = Keys.Right Then
            'If we are not pointing straight horizontal
            If cannonBarrel.Angle > 0 Then
                'rotate forwards (clockwise)
                cannonBarrel.ChangeAngle(-1)
            End If

            'If the user is pressing the spacebar key
        ElseIf e.KeyCode = Keys.Space Then
            'set the flag to True - we will check this in our Timer event
            isSpacePressed = True
        End If

    End Sub

    ' This method provided complete in the Activity Starter
    Private Sub IceCreamForm_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyUp

        'If the user has let go of the spacebar key
        If e.KeyCode = Keys.Space Then
            'Shoot the ice cream shot
            ShootIceCream()
            'set the velocity back to 0
            velocity = 0
            'set the flag back to 0
            isSpacePressed = False
            'Hide the progress bar until we need it again
            ProgressBar1.Visible = False
        End If
    End Sub

    ' This method provided complete in the Activity Starter
    Private Sub TossTimer_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TossTimer.Tick

        'Move the shot on the screen
        MoveIceCream()

        'Check to see if the shot has hit the cone
        CheckCollisions()

        'If the user is pressing the spacebar
        If isSpacePressed Then
            'turn on the progressbar
            ProgressBar1.Visible = True
            'if the velocity has not hit the max, add .2 to it
            If velocity < 10.0 Then
                velocity += 0.2
            End If
            'Update the progressbar
            ProgressBar1.Value = velocity
        End If

        'Repaint the screen
        Invalidate()
    End Sub


    ' This method provided complete in the Activity Starter
    Private Sub IceCreamForm_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles Me.Paint
        'Create a basic graphics object for the other images - this will NOT be rotated
        Dim myGraphics As Graphics = e.Graphics

        'Create a solid brush to draw the ice cream shot
        Dim scoopBrush As SolidBrush = New SolidBrush(Color.HotPink)

        'If the scoop shot is alive, draw it on the screen
        If (scoopShot.IsAlive) Then
            myGraphics.FillEllipse(scoopBrush, scoopShot.GetBoundingRectangle())
        End If

        'Draw the cannon barrel rotated on the screen
        cannonBarrel.PaintRotatedImage(myGraphics, cannonBarrel.Angle, cannonBarrel.GetCenter(), True)

        shootingPoint.X = cannonBarrel.UpperLeft.X + cannonBarrel.GetBoundingRectangle.Width
        shootingPoint.Y = cannonBarrel.UpperLeft.Y + cannonBarrel.GetBoundingRectangle.Height / 2

        'As the cannon barrel is rotated, we need to keep track of the tip of the barrel
        'This will allow us to shoot from this point
        cannonBarrel.RotatePoint(cannonBarrel.GetCenter(), shootingPoint)

        'Paint the cannon wheel and ice cream cone on the screen
        cannonWheel.PaintImage(myGraphics, True)
        iceCreamConeTop.PaintImage(myGraphics, True)
        iceCreamCone.PaintImage(myGraphics, True)

        'Draw the scoop hits, if there are any
        Select Case iNumHits
            Case 1 ' one hit - one scoop
                myGraphics.FillEllipse(scoopBrush, iceCreamConeTop.UpperLeft.X + 5, iceCreamConeTop.UpperLeft.Y + 5, iceCreamConeTop.loadedImage.Width - 10, 10)

            Case 2 ' two hits - two scoops
                myGraphics.FillEllipse(scoopBrush, iceCreamConeTop.UpperLeft.X + 5, iceCreamConeTop.UpperLeft.Y + 5, iceCreamConeTop.loadedImage.Width - 10, 10)
                myGraphics.FillEllipse(scoopBrush, iceCreamConeTop.UpperLeft.X + 10, iceCreamConeTop.UpperLeft.Y - 15, iceCreamConeTop.loadedImage.Width - 20, 30)

            Case 3 ' three hits - three scoops
                myGraphics.FillEllipse(scoopBrush, iceCreamConeTop.UpperLeft.X + 5, iceCreamConeTop.UpperLeft.Y + 5, iceCreamConeTop.loadedImage.Width - 10, 10)
                myGraphics.FillEllipse(scoopBrush, iceCreamConeTop.UpperLeft.X + 10, iceCreamConeTop.UpperLeft.Y - 15, iceCreamConeTop.loadedImage.Width - 20, 30)
                myGraphics.FillEllipse(scoopBrush, iceCreamConeTop.UpperLeft.X + 15, iceCreamConeTop.UpperLeft.Y - 35, iceCreamConeTop.loadedImage.Width - 30, 50)
        End Select

    End Sub

    ' This method will be completed by the student in a Your Turn activity 
    Private Sub ShootIceCream()

    End Sub

    ' This method will be completed by the student in a Your Turn activity 
    Private Sub MoveIceCream()

      
    End Sub


    ' This method will be completed by the student in a Your Turn activity 
    Private Sub CheckCollisions()
        
    End Sub

    ' This method provided complete in the Activity Starter
    Public Sub CalculateWind()
        'Create a random number generator that will be used to generate a random wind value
        Dim RandomNumGen As New Random(Now.Millisecond)

        'Generate a random double value between 0 and 1
        currentWind = RandomNumGen.NextDouble()

        'multiply this number by either -1, 0, or 1. This will give a random negative or positive value to our wind
        currentWind = currentWind * RandomNumGen.Next(-1, 2)

        ' update the label that describe the current wind acceleration
        WindLabel.Text = "Wind: " & (currentWind * 100).ToString("F0") & "%"

        'Dividing this number by 33 will keep this value between 0 and .03, 
        'which 'feels like' a good wind resistance for our game
        currentWind /= 33

    End Sub
    
    Private Sub SaveFileDialog1_FileOk(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles SaveFileDialog1.FileOk

    End Sub
End Class
