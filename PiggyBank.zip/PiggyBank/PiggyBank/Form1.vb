﻿Public Class BankForm

    ' this structure represents one deposit or withdrawal
    Public Structure Transaction
        Dim amount As Decimal
        Dim time As Date
    End Structure

    ' this array contains all known transactions (initially empty with length 0)
    Dim transactions(-1) As Transaction

    ' this handy function will add a new transaction onto the end of our array
    Private Sub addTransaction(ByVal dollarAmount As Decimal)

        ' declare an index variable representing a new transaction we will add to the end of the array
        Dim i As Integer = transactions.Length

        ' add one transaction to the end of the array, keeping all prior transactions
        ReDim Preserve transactions(i)

        ' update the last transaction in the array with the dollar amount and current time
        transactions(i).amount = dollarAmount
        transactions(i).time = Date.Now

    End Sub

    Private Sub ButtonDeposit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DepositButton.Click

        ' when the deposit button is clicked, add a new deposit (positive amount) to the array
        addTransaction(dollarAmount.Value)

    End Sub

    Private Sub ButtonWithdrawal_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles WithdrawalButton.Click

        ' when the withdrawal button is clicked, add a new withdrawal (negative amount) to the array
        addTransaction(-dollarAmount.Value)

    End Sub


    Private Sub BankForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
