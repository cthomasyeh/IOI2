﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class DancingForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ShapeContainer1 = New Microsoft.VisualBasic.PowerPacks.ShapeContainer()
        Me.DancingCircle = New Microsoft.VisualBasic.PowerPacks.OvalShape()
        Me.DancingSquare = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.SuspendLayout()
        '
        'ShapeContainer1
        '
        Me.ShapeContainer1.Location = New System.Drawing.Point(0, 0)
        Me.ShapeContainer1.Margin = New System.Windows.Forms.Padding(0)
        Me.ShapeContainer1.Name = "ShapeContainer1"
        Me.ShapeContainer1.Shapes.AddRange(New Microsoft.VisualBasic.PowerPacks.Shape() {Me.DancingCircle, Me.DancingSquare})
        Me.ShapeContainer1.Size = New System.Drawing.Size(554, 478)
        Me.ShapeContainer1.TabIndex = 0
        Me.ShapeContainer1.TabStop = False
        '
        'DancingCircle
        '
        Me.DancingCircle.FillColor = System.Drawing.Color.Red
        Me.DancingCircle.FillStyle = Microsoft.VisualBasic.PowerPacks.FillStyle.Solid
        Me.DancingCircle.Location = New System.Drawing.Point(337, 268)
        Me.DancingCircle.Name = "DancingCircle"
        Me.DancingCircle.Size = New System.Drawing.Size(130, 130)
        '
        'DancingSquare
        '
        Me.DancingSquare.FillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.DancingSquare.FillStyle = Microsoft.VisualBasic.PowerPacks.FillStyle.Solid
        Me.DancingSquare.Location = New System.Drawing.Point(62, 56)
        Me.DancingSquare.Name = "DancingSquare"
        Me.DancingSquare.Size = New System.Drawing.Size(125, 125)
        '
        'DancingForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(554, 478)
        Me.Controls.Add(Me.ShapeContainer1)
        Me.DoubleBuffered = True
        Me.KeyPreview = True
        Me.Name = "DancingForm"
        Me.Text = "Dancing Shapes"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents ShapeContainer1 As Microsoft.VisualBasic.PowerPacks.ShapeContainer
    Friend WithEvents DancingCircle As Microsoft.VisualBasic.PowerPacks.OvalShape
    Friend WithEvents DancingSquare As Microsoft.VisualBasic.PowerPacks.RectangleShape

End Class
