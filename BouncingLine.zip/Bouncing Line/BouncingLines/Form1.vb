﻿' Starter for the BouncingLine project: December 14 and 15 exercise

Public Class BounceForm
    Dim point1Direction As Point
    Dim point2Direction As Point

    Private Sub LineTimer_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LineTimer.Tick

    End Sub

    Private Sub MoveLine()
        

    End Sub

    Private Sub StartButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StartButton.Click

    End Sub

End Class
