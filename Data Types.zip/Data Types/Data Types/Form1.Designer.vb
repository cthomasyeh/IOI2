﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class DataTypeForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.NumericButton = New System.Windows.Forms.Button
        Me.CharButton = New System.Windows.Forms.Button
        Me.BoolButton = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'NumericButton
        '
        Me.NumericButton.Location = New System.Drawing.Point(104, 25)
        Me.NumericButton.Name = "NumericButton"
        Me.NumericButton.Size = New System.Drawing.Size(97, 23)
        Me.NumericButton.TabIndex = 0
        Me.NumericButton.Text = "Numeric Type"
        Me.NumericButton.UseVisualStyleBackColor = True
        '
        'CharButton
        '
        Me.CharButton.Location = New System.Drawing.Point(104, 71)
        Me.CharButton.Name = "CharButton"
        Me.CharButton.Size = New System.Drawing.Size(97, 23)
        Me.CharButton.TabIndex = 1
        Me.CharButton.Text = "Character Type"
        Me.CharButton.UseVisualStyleBackColor = True
        '
        'BoolButton
        '
        Me.BoolButton.Location = New System.Drawing.Point(104, 118)
        Me.BoolButton.Name = "BoolButton"
        Me.BoolButton.Size = New System.Drawing.Size(97, 23)
        Me.BoolButton.TabIndex = 2
        Me.BoolButton.Text = "Boolean Type"
        Me.BoolButton.UseVisualStyleBackColor = True
        '
        'DataTypeForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(292, 174)
        Me.Controls.Add(Me.BoolButton)
        Me.Controls.Add(Me.CharButton)
        Me.Controls.Add(Me.NumericButton)
        Me.Name = "DataTypeForm"
        Me.Text = "Data Type Example"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents NumericButton As System.Windows.Forms.Button
    Friend WithEvents CharButton As System.Windows.Forms.Button
    Friend WithEvents BoolButton As System.Windows.Forms.Button

End Class
