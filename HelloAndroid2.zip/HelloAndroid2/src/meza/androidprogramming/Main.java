package meza.androidprogramming;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;


//The main class file for this screen 
//This class implements OnClickListener to handle button clicks on the screen
public class Main extends Activity implements OnClickListener
{

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		// 	Get a reference to our 3 buttons on the screen
		Button btnSDKVer = (Button) findViewById(R.id.buttonOS);
		Button btnETime = (Button)findViewById(R.id.buttonTime);
		

		// 	Set the OnClickListeners for the buttons on the screen
		btnSDKVer.setOnClickListener(this);
		btnETime.setOnClickListener(this);
		
	}

	// The onClick() method will be called when a user presses a button
	// on the screen.
	public void onClick(View v)
	{
		// Create a new Intent to switch to the Second screen
		Intent secondIntent = new Intent(Main.this, Second.class);	

		// Get the id value of the control that was clicked
		int id = v.getId();

		// If the OS button was clicked
		if (id == R.id.buttonOS)
		{
			// 	Add the OS version to the Intent
			secondIntent.putExtra("build", android.os.Build.VERSION.RELEASE);

			// Start the new Activity referenced by the Intent
			startActivity(secondIntent);
		}

		// 	If the Time button was clicked
		else if (id == R.id.buttonTime)
		{
			// Add the "uptime" for the emulator to the Intent
			secondIntent.putExtra("time", SystemClock.uptimeMillis());

			// Start the new Activity referenced by the Intent
			startActivity(secondIntent);
		}

		
	}


	


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
    
}
