﻿Imports System.Math
Imports System.Media

Public Class BlasterForm
    Dim mySoundPlayer As SoundPlayer = New SoundPlayer
    ' ====================================================
    ' these constants control some of the game parameters 

    ' maximum ship speed, acceleration rate
    Dim MAX_SHIP_SPEED As Double = 15.0
    Dim SHIP_ACCELERATION As Double = 1.5

    ' shot speed and lifespan
    Dim SHOT_SPEED As Double = 20.0
    Dim SHOT_TIME_TO_LIVE As Integer = 15
    Dim SHIELD_TIME_TO_LIVE As Integer = 30

    ' speed of big, medium, and small bubbles
    Dim BIG_BUBBLE_SPEED As Double = 2.0
    Dim MED_BUBBLE_SPEED As Double = 3.0
    Dim SML_BUBBLE_SPEED As Double = 4.0

    ' number of big bubbles to start
    Dim NUM_BIG_BUBBLES As Integer = 3

    ' maximum number of ship shots that can be on the screen at once
    Dim MAX_SHIP_SHOTS As Integer = 10
    Dim currentShot As Integer = 0


    ' Sound variables for the game sounds
    Dim shotSound As SoundPlayer = New SoundPlayer
    Dim explodeSound As SoundPlayer = New SoundPlayer
    Dim accelerateSound As SoundPlayer = New SoundPlayer
    Dim gameOverSound As SoundPlayer = New SoundPlayer

    ' ====================================================
    ' game state

    ' All bubbles are contained in this array of Sprites
    Dim bubbleArray(NUM_BIG_BUBBLES - 1) As Sprite

    ' All ship shots are contained in this array of Sprites
    Dim shipShots(MAX_SHIP_SHOTS - 1) As Sprite

    ' The player's spaceship is represented by one instance of a Sprite
    Dim myShip As Sprite
    Dim myShield As Sprite


    ' the gameStopped variables are used to signal end-of-game condition to the timer loop
    Dim gameStopped As Boolean
    Dim gameStoppedMessage As String

    ' these boolean variables track which key(s) are currently down at any time
    Dim keyLeftPressed As Boolean
    Dim keyRightPressed As Boolean
    Dim keyUpPressed As Boolean
    Dim keySpacePressed As Boolean
    Dim keyDownPressed As Boolean
    Dim keyShiftPressed As Boolean


    ' random number generator is used in a number of places
    Dim RandomNumGen As New System.Random

    ' This method provided complete in the Activity Starter
    Private Sub StartGame()
        ' this method contains all of the game state initialization necessary to start a new game

        gameStopped = False     ' indicate that the game is not stopped

        ' call methods to initialize the bubbles array, shots array, and ship structure
        InitializeBubbles()
        InitializeShots()
        InitializeShip()
        InitializeSounds()

        ' clear out all key states, assume nothing pressed to start
        keyLeftPressed = False
        keyRightPressed = False
        keyUpPressed = False
        keySpacePressed = False
        keyShiftPressed = False
        ' start the timer that will call our main game loop
        BlasterTimer.Start()

    End Sub

    ' This method provided complete in the Activity Starter
    Private Sub StopGame(ByVal message As String)
        ' This method will be called when the game logic detects that the game is over.

        ' set the gameStopped flag to true and save the message for later display in the timer loop
        gameStopped = True
        gameStoppedMessage = message
    End Sub

    ' This method provided complete in the Activity Starter
    Private Sub BlasterTimer_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BlasterTimer.Tick

        ' This is the main game loop called by the form timer every 100 milliseconds (10 times a second)
        ' Within the main game loop, we respond to any keys that are pressed, move all of the sprites around the screen,
        ' check to see if there are any collisions, check to see if the game is over, and force the screen to repaint

        ' check to see if the user has pressed any keys and respond accordingly
        ProcessKeys()

        ' move all the sprites
        MoveShip()
        MoveBubbles()
        MoveShots()

        ' check for collisions and end-of-game conditions
        CheckShotCollisions()
        CheckShipCollisions()
        CheckIfWinner()

        ' if game should be stopped
        If (gameStopped) Then
            BlasterTimer.Stop()   ' stop the timer
            MsgBox(gameStoppedMessage)  ' display the end-of-game message

            StartGame() ' automatically start another game
        End If

        ' signal screen to repaint
        Invalidate()

    End Sub

    ' This method provided complete in the Activity Starter
    Private Sub BlasterForm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'when the form loads we want to stop the game automatically
        mySoundPlayer.Stream = My.Resources.Welcome
        mySoundPlayer.Play()
        StartGame()
    End Sub

    ' This method provided complete in the Activity Starter
    Private Sub BlasterForm_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles Me.Paint

        ' The Form1_Paint method is called 10 times a second when the screen is invalidated by the timer tick method.

        Dim myGraphics As Graphics = e.Graphics

        ' Within this method we draw all of the sprite objects on the screen (bubbles, ship, shots)
        PaintBubbles(myGraphics)
        PaintShip(myGraphics)
        PaintShots(myGraphics)

    End Sub

    ' This method will be completed by the student in a Your Turn activity 
    Private Sub InitializeBubbles()
        ReDim bubbleArray(NUM_BIG_BUBBLES - 1)
        For i = 0 To NUM_BIG_BUBBLES - 1
            bubbleArray(i) = New Sprite()
            bubbleArray(i).SetImageResource(My.Resources.bubble_large)
            bubbleArray(i).UpperLeft.X = RandomNumGen.Next(Me.ClientSize.Width)
            bubbleArray(i).UpperLeft.Y = RandomNumGen.Next(Me.ClientSize.Height)
            bubbleArray(i).Angle = RandomNumGen.Next(0, 360)
            bubbleArray(i).SetVelocity(5)
            bubbleArray(i).MaxSpeed = BIG_BUBBLE_SPEED
        Next
    End Sub

    ' This method will be completed by the student in a Your Turn activity 
    Private Sub PaintBubbles(ByRef myGraphics As Graphics)
        For i = 0 To bubbleArray.Length - 1
            If (bubbleArray(i).IsAlive) Then
                bubbleArray(i).PaintImage(myGraphics, True)
            End If
        Next

    End Sub

    ' This method will be completed by the student in a Your Turn activity 
    Private Sub MoveBubbles()
        For i = 0 To bubbleArray.Length - 1
            If (bubbleArray(i).IsAlive) Then
                bubbleArray(i).MoveAndWrap(Me.ClientSize)
            End If
        Next

    End Sub


    ' This method provided complete in the Activity Starter
    Private Sub PaintShip(ByRef myGraphics As Graphics)

        'Make sure that the ship exists on the screen
        If (myShip Is Nothing) Then
            Return
        End If

        ' paint the ship image at it's current rotation angle
        myShip.PaintRotatedImage(myGraphics, myShip.Angle, myShip.GetCenter(), True)
        If (myShield.IsAlive) Then
            myShield.PaintRotatedImage(myGraphics, myShip.Angle, myShip.GetCenter(), True)
        End If

    End Sub

    ' This method will be completed by the student in a Your Turn activity 
    Private Sub InitializeShip()
        myShip = New Sprite()
        myShip.SetImageResource(My.Resources.BBShip)
        myShield = New Sprite()
        myShield.SetImageResource(My.Resources.shield)
        Dim centerPoint As Point
        centerPoint.X = Me.ClientSize.Width / 2
        centerPoint.Y = Me.ClientSize.Height / 2
        myShip.SetCenter(centerPoint)
        myShip.MaxSpeed = MAX_SHIP_SPEED
        myShield.SetCenter(centerPoint)
        myShield.MaxSpeed = MAX_SHIP_SPEED
        myShield.TimeToLive = SHIELD_TIME_TO_LIVE
        myShield.IsAlive = True
    End Sub

    ' This method will be completed by the student in a Your Turn activity 
    Private Sub BlasterForm_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        Select Case e.KeyCode.ToString()
            Case "Left"
                keyLeftPressed = True
            Case "Right"
                keyRightPressed = True
            Case "Up"
                keyUpPressed = True
            Case "Space"
                keySpacePressed = True
            Case "Down"
                keyDownPressed = True
            Case "ShiftKey"
                keyShiftPressed = True
        End Select

    End Sub

    ' This method will be completed by the student in a Your Turn activity 
    Private Sub BlasterForm_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyUp
        Select Case e.KeyCode.ToString()
            Case "Left"
                keyLeftPressed = False
            Case "Right"
                keyRightPressed = False
            Case "Up"
                keyUpPressed = False
            Case "Space"
                keySpacePressed = False 
            Case "Down"
                keyDownPressed = False
            Case "ShiftKey"
                keyShiftPressed = False
        End Select
        
    End Sub

    ' This method will be completed by the student in a Your Turn activity 
    Private Sub ProcessKeys()
        If keyLeftPressed = True Then
            myShip.ChangeAngle(10)
            myShield.ChangeAngle(10)
        End If
        If keyRightPressed = True Then
            myShip.ChangeAngle(-10)
            myShield.ChangeAngle(-10)
        End If
        If keyUpPressed = True Then
            myShip.Accelerate(SHIP_ACCELERATION)
            myShield.Accelerate(SHIP_ACCELERATION)
            accelerateSound.Play()
        End If
        If keySpacePressed = True Then
            Shoot()
        End If
        If KeyDownPressed = True Then
            myShip.SetVelocity(0)
            myShield.SetVelocity(0)
        End If
        If keyShiftPressed = True Then
            myShield.SetImageResource(My.Resources.shield)
            myShield.IsAlive = True
            myShield.SetCenter(myShip.GetCenter())
            myShield.MaxSpeed = MAX_SHIP_SPEED
            myShield.TimeToLive = SHIELD_TIME_TO_LIVE
        End If

    End Sub

    ' This method will be completed by the student in a Your Turn activity 
    Private Sub MoveShip()
        myShip.MoveAndWrap(Me.ClientSize)
        myShield.MoveAndWrap(Me.ClientSize)
    End Sub


    ' This method will be completed by the student in a Your Turn activity 
    Private Sub InitializeShots()
        For i = 0 To shipShots.Length - 1
            shipShots(i) = New Sprite()
            shipShots(i).IsAlive = False
            shipShots(i).TimeToLive = SHOT_TIME_TO_LIVE
            shipShots(i).SetImageResource(My.Resources.shot)
            shipShots(i).MaxSpeed = SHOT_SPEED
        Next
    End Sub

    ' This method will be completed by the student in a Your Turn activity 
    Private Sub Shoot()
        If currentShot = MAX_SHIP_SHOTS - 1 Then
            currentShot = 0
        Else
            currentShot = currentShot + 1
        End If
        If (shipShots(currentShot).IsAlive = False) Then
            shipShots(currentShot).IsAlive = True
            shipShots(currentShot).TimeToLive = SHOT_TIME_TO_LIVE
            shipShots(currentShot).Angle = myShip.Angle
            shipShots(currentShot).SetVelocity(SHOT_SPEED)
            shipShots(currentShot).UpperLeft = myShip.GetCenter()
            shotSound.Play()
        End If
    End Sub


    ' This method will be completed by the student in a Your Turn activity 
    Private Sub MoveShots()
        For i = 0 To shipShots.Length - 1
            shipShots(i).MoveAndWrap(Me.ClientSize)
        Next

    End Sub


    ' This method will be completed by the student in a Your Turn activity 
    Private Sub PaintShots(ByRef myGraphics As Graphics)
        For i = 0 To shipShots.Length - 1
            If (shipShots(i).IsAlive) Then
                shipShots(i).PaintImage(myGraphics, True)
            End If
        Next
    End Sub



    ' This method will be completed by the student in a Your Turn activity 
    Private Sub CheckShipCollisions()
        For i = 0 To bubbleArray.Length - 1
            If bubbleArray(i).IsCollided(myShip) Then
                If (myShield.IsAlive = False) Then
                    myShip.IsAlive = False
                End If
            End If
        Next
        If myShip.IsAlive = False Then
            gameOverSound.Play()
            StopGame("You lose!")
        End If
    End Sub


    ' This method will be completed by the student in a Your Turn activity 
    Private Sub CheckShotCollisions()
        For i = 0 To MAX_SHIP_SHOTS - 1
            For j = 0 To bubbleArray.Length - 1
                If (bubbleArray(j).IsCollided(shipShots(i)) = True) Then
                    ExplodeBubble(bubbleArray(j))
                    explodeSound.Play()
                End If

            Next
        Next
    End Sub


    ' This method will be completed by the student in a Your Turn activity 
    Private Sub CheckIfWinner()
        Dim isAnyoneAlive As Boolean = False
        For i = 0 To bubbleArray.Length - 1
            If bubbleArray(i).IsAlive = True Then
                isAnyoneAlive = True
            End If
        Next
        If (isAnyoneAlive = False) Then
            StopGame("you won!!!!!!")
        End If
    End Sub


    ' This method provided complete in the Activity Starter
    Private Sub ExplodeBubble(ByRef bubble As Sprite)
        ' this bubble is now gone
        bubble.IsAlive = False

        ' create new bubbles depending on the exploded bubble's size

        If (bubble.Size.X = My.Resources.bubble_large.Size.Width) Then

            ' exploded bubble was big
            ' create two medium bubbles starting at the location of the one that exploded
            CreateSmallerBubble(My.Resources.bubble_medium, MED_BUBBLE_SPEED, bubble.UpperLeft)
            CreateSmallerBubble(My.Resources.bubble_medium, MED_BUBBLE_SPEED, bubble.UpperLeft)

        ElseIf (bubble.Size.X = My.Resources.bubble_medium.Size.Width) Then

            ' exploded bubble was medium
            ' create two small bubbles starting at the location of the one that exploded
            CreateSmallerBubble(My.Resources.bubble_small, SML_BUBBLE_SPEED, bubble.UpperLeft)
            CreateSmallerBubble(My.Resources.bubble_small, SML_BUBBLE_SPEED, bubble.UpperLeft)

        Else
            ' exploded bubble was small
            ' nothing to do for the smallest bubbles, they are just marked isAlive = false above
        End If

    End Sub

    ' This method provided complete in the Activity Starter
    Private Sub CreateSmallerBubble(ByRef bubbleImage As System.Drawing.Image, ByVal speed As Integer, ByVal position As Point)

        ' find out where this new bubble will be indexed at the end of the current bubbles array
        Dim newBubbleIndex = bubbleArray.Length

        ' increase the bubble array size by 1, preserving previous elements!
        ReDim Preserve bubbleArray(newBubbleIndex)

        ' add a new bubble at the end of the array using the provided size, speed, and position and random angle
        bubbleArray(newBubbleIndex) = New Sprite
        bubbleArray(newBubbleIndex).MaxSpeed = speed
        bubbleArray(newBubbleIndex).UpperLeft = position

        'Set the new bubble's random Angle and set its velocity
        bubbleArray(newBubbleIndex).Angle = RandomNumGen.Next(0, 360)
        bubbleArray(newBubbleIndex).SetVelocity(5)

        ' set the new bubble's image resourse (which automatically adjusts the Size also)
        bubbleArray(newBubbleIndex).SetImageResource(bubbleImage)

    End Sub

    ' This method will be completed by the student in a lesson
    Private Sub InitializeSounds()
        shotSound.Stream = My.Resources.bubbles_shot
        explodeSound.Stream = My.Resources.bubble_explosion
        accelerateSound.Stream = My.Resources.bubbles_accelerate
        gameOverSound.Stream = My.Resources.bubbles_shipdestroyed
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs)

    End Sub
End Class

