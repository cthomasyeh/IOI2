﻿
Imports System.Drawing.Printing

Public Class WordForm

    ' determine how many rows and columns we want in our grid
    Const NUM_ROWS As Integer = 15
    Const NUM_COLUMNS As Integer = 15
    Const NUM_HIDDEN_WORDS As Integer = 4

    ' cellSize will store the square cell size in pixels
    Dim cellSize As Integer

    ' this 2D array will hold the individual characters
    Dim characterGrid(NUM_COLUMNS - 1, NUM_ROWS - 1) As Char

    ' this array of string will hold the hidden words entered by the user
    Dim hiddenWords(NUM_HIDDEN_WORDS - 1) As String

    ' random number generator for placing hidden words in random locations,
    ' and generating random letters to fill in the remaining spaces
    Dim RandomNumGen As New System.Random


    ' This method provided complete in the Activity Starter
    Private Sub WordForm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'Call the StartGame function when the program begins
        StartGame()
    End Sub

    ' This method provided complete in the Activity Starter
    Private Sub StartGame()

        'This function will create the word search game board
        ' Determine the cell size based on the initial form dimensions
        'Figure out which size is bigger - the height or width of the form
        'Divide the smaller size by the number of rows in our grid to get the cell size
        If (Me.ClientSize.Height > Me.ClientSize.Width) Then
            cellSize = (Me.ClientSize.Width / NUM_ROWS)
        Else
            'If the height is smaller than width we still want to leave room for the word key, 
            ' so we subtract 100 pixels 
            cellSize = ((Me.ClientSize.Height - 100) / NUM_ROWS)
        End If

        ' initialize the cells
        For i = 0 To NUM_COLUMNS - 1
            For j = 0 To NUM_ROWS - 1
                characterGrid(i, j) = " "
            Next
        Next

        'Load the hidden words
        LoadHiddenWords()

        'load the random letters around the hidden words
        LoadRandomLetters()

        'repaint the screen
        Invalidate()

    End Sub

    ' This method provided complete in the Activity Starter
    Private Sub LoadHiddenWords()

        'This function will load the hidden words into the cell grid
        'Set the heading for the KeyLabel text
        KeyLabel.Text = ""

        'Loop through the HiddenWords array
        For i = 0 To NUM_HIDDEN_WORDS - 1
            'Ask the user to supply a word to hide
            hiddenWords(i) = InputBox("Enter search word # " & (i + 1).ToString() & ": ")

            'Call the PlaceHiddenWord function to place the word in a random location on the screen
            PlaceHiddenWord(hiddenWords(i))

            'Add the word to the Word Key
            KeyLabel.Text = KeyLabel.Text & hiddenWords(i).ToUpper
            If (i <> NUM_HIDDEN_WORDS - 1) Then
                KeyLabel.Text = KeyLabel.Text & ", "
            End If

        Next
    End Sub

    ' This method provided complete in the Activity Starter
    Public Sub LoadRandomLetters()

        'Function which adds random letters around the (already placed) hidden words
        'Loop through the columns and rows of the cell grid
        For i = 0 To NUM_COLUMNS - 1
            For j = 0 To NUM_ROWS - 1
                'If the current cell is empty, create a random letter to fill it
                If characterGrid(i, j) = " " Then
                    characterGrid(i, j) = GenerateRandomLetter()
                End If
            Next
        Next
    End Sub

    ' This method provided complete in the Activity Starter
    Public Function GenerateRandomLetter() As Char
        'Function generates a random number from 65 to 90, which is an ASCII A to Z
        'Then change this number to a char and return
        Return (Chr(RandomNumGen.Next(65, 91)))
    End Function

    ' This method provided complete in the Activity Starter
    Public Sub PlaceHiddenWord(ByVal Word As String)
        'This function will place the hidden word on the screen in a random location and direction
        Dim isPlaced As Boolean = False
        Dim xDirection, yDirection, xCell, yCell As Integer

        While (isPlaced = False)

            'xDirection and yDirection is between -1 and 1
            '-1 moves x in the left direction and y in the up direction
            '0 does not move in either the x or y direction
            '1 moves x in the right direction and y in the down direction

            'we can't have BOTH xDirection and yDirection as 0, since all letters would print in same space
            While (xDirection = 0 And yDirection = 0)
                xDirection = RandomNumGen.Next(-1, 2)
                yDirection = RandomNumGen.Next(-1, 2)
            End While

            'Find a random cell by getting a random number for the x and y value in the cellArray
            xCell = RandomNumGen.Next(0, NUM_COLUMNS)
            yCell = RandomNumGen.Next(0, NUM_ROWS)

            'For all the letters in the 'Word'
            For i = 0 To Word.Length - 1
                'If the current cell is occupied, this is a failure to place, so Exit For and try again
                If (characterGrid(xCell, yCell) <> " ") Then
                    isPlaced = False
                    Exit For
                Else 'current cell is empty
                    isPlaced = True

                    'increment current x cell (row) by xDirection
                    xCell += xDirection

                    'increment current y cell (column) by yDirection
                    yCell += yDirection

                    'If this isn't the last iteration of the for loop we need to verify
                    'that the cell is still within the grid boundaries.  On the last loop
                    'iteration the cell position will be one past the end of our word so
                    'we don't care at that point.
                    If (i < Word.Length - 1) Then

                        'If this cell is off of the screen, can't place word, so Exit For and try again
                        If (xCell < 0) Or xCell >= NUM_COLUMNS Then
                            isPlaced = False
                            Exit For
                        End If

                        'If this cell is off of the screen, can't place word, so Exit For and try again
                        If (yCell < 0) Or yCell >= NUM_ROWS Then
                            isPlaced = False
                            Exit For
                        End If
                    End If

                End If
            Next
        End While

        'If we get this far, we have found a spot for the word, so we will write it to the screen
        'We will start at the current xCell and yCell (which were the last cells tested) and work backward
        'For all the letters in 'Word'
        For i = 0 To Word.Length - 1

            'walk backward through the cells that we checked to place the word
            xCell -= xDirection
            yCell -= yDirection

            'Write the current letter as upper case to the screen
            characterGrid(xCell, yCell) = Word.Substring(i, 1).ToUpper
        Next

    End Sub


    ' This function will be completed by the student in a Your Turn activity.
    Private Sub WordForm_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles Me.Paint

       
    End Sub


    ' This function will be completed by the student in a Your Turn activity.
    Private Sub PrintButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PrintButton.Click

     
    End Sub

    ' This function will be completed by the student in a Your Turn activity.
    Private Sub PrintDocument1_PrintPage(ByVal sender As Object, ByVal e As System.Drawing.Printing.PrintPageEventArgs) Handles PrintDocument1.PrintPage

        '*****The following lines are provided complete as part of the activity starter*****
        'Create a graphics object for our printed page
        Dim printGraphics As Graphics = e.Graphics

        'Create a brush that will be used to paint the letters on the page
        Dim WordBrush As New SolidBrush(Color.Black)

        'Create a pen that will be used to paint the line between the grid and the word key
        Dim linePen As New Pen(Color.Black, 2)

        'letterwidth and letterheight are used to figure out how big to make 
        'letters on the paper and to increment the 'lines' that are printed

        Dim letterWidth As Integer = e.MarginBounds.Width / NUM_COLUMNS

        ' Add 3 lines for word key verbage and then lines for hidden words
        Dim letterHeight As Integer = e.MarginBounds.Height / (NUM_ROWS + 3 + NUM_HIDDEN_WORDS)

        'These variables hold the current x and y positions for the letter being drawn
        Dim currentXposition, currentYPosition As Integer

        '*****The following lines should be added by the student as part of the activity*****

       
    End Sub

End Class
