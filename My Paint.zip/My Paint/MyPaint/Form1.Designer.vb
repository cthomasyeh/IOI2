﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PaintForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.EllipseRadio = New System.Windows.Forms.RadioButton()
        Me.RectangleRadio = New System.Windows.Forms.RadioButton()
        Me.LineRadio = New System.Windows.Forms.RadioButton()
        Me.FilledEllipseRadio = New System.Windows.Forms.RadioButton()
        Me.GradientRectangleRadio = New System.Windows.Forms.RadioButton()
        Me.SuspendLayout()
        '
        'EllipseRadio
        '
        Me.EllipseRadio.AutoSize = True
        Me.EllipseRadio.Checked = True
        Me.EllipseRadio.Location = New System.Drawing.Point(12, 12)
        Me.EllipseRadio.Name = "EllipseRadio"
        Me.EllipseRadio.Size = New System.Drawing.Size(83, 17)
        Me.EllipseRadio.TabIndex = 0
        Me.EllipseRadio.TabStop = True
        Me.EllipseRadio.Text = "Draw Ellipse"
        Me.EllipseRadio.UseVisualStyleBackColor = True
        '
        'RectangleRadio
        '
        Me.RectangleRadio.AutoSize = True
        Me.RectangleRadio.Location = New System.Drawing.Point(12, 58)
        Me.RectangleRadio.Name = "RectangleRadio"
        Me.RectangleRadio.Size = New System.Drawing.Size(102, 17)
        Me.RectangleRadio.TabIndex = 1
        Me.RectangleRadio.Text = "Draw Rectangle"
        Me.RectangleRadio.UseVisualStyleBackColor = True
        '
        'LineRadio
        '
        Me.LineRadio.AutoSize = True
        Me.LineRadio.Location = New System.Drawing.Point(12, 104)
        Me.LineRadio.Name = "LineRadio"
        Me.LineRadio.Size = New System.Drawing.Size(73, 17)
        Me.LineRadio.TabIndex = 2
        Me.LineRadio.Text = "Draw Line"
        Me.LineRadio.UseVisualStyleBackColor = True
        '
        'FilledEllipseRadio
        '
        Me.FilledEllipseRadio.AutoSize = True
        Me.FilledEllipseRadio.Location = New System.Drawing.Point(12, 35)
        Me.FilledEllipseRadio.Name = "FilledEllipseRadio"
        Me.FilledEllipseRadio.Size = New System.Drawing.Size(110, 17)
        Me.FilledEllipseRadio.TabIndex = 4
        Me.FilledEllipseRadio.Text = "Draw Filled Ellipse"
        Me.FilledEllipseRadio.UseVisualStyleBackColor = True
        '
        'GradientRectangleRadio
        '
        Me.GradientRectangleRadio.AutoSize = True
        Me.GradientRectangleRadio.Location = New System.Drawing.Point(12, 81)
        Me.GradientRectangleRadio.Name = "GradientRectangleRadio"
        Me.GradientRectangleRadio.Size = New System.Drawing.Size(145, 17)
        Me.GradientRectangleRadio.TabIndex = 6
        Me.GradientRectangleRadio.Text = "Draw Gradient Rectangle"
        Me.GradientRectangleRadio.UseVisualStyleBackColor = True
        '
        'PaintForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(565, 378)
        Me.Controls.Add(Me.GradientRectangleRadio)
        Me.Controls.Add(Me.FilledEllipseRadio)
        Me.Controls.Add(Me.LineRadio)
        Me.Controls.Add(Me.RectangleRadio)
        Me.Controls.Add(Me.EllipseRadio)
        Me.DoubleBuffered = True
        Me.Name = "PaintForm"
        Me.Text = "My Paint Program"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents EllipseRadio As System.Windows.Forms.RadioButton
    Friend WithEvents RectangleRadio As System.Windows.Forms.RadioButton
    Friend WithEvents LineRadio As System.Windows.Forms.RadioButton
    Friend WithEvents FilledEllipseRadio As System.Windows.Forms.RadioButton
    Friend WithEvents GradientRectangleRadio As System.Windows.Forms.RadioButton

End Class
