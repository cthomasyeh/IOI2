package meza.androidprogramming;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

//The main class file for this screen 
//This class implements OnClickListener to handle button clicks on the screen
public class Second extends Activity 
{
	 /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) 
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.second);
        
        // get Intent that launched this activity
        Intent myIntent = getIntent();
        	    
        // get Bundle which contains extra data
        Bundle bun = myIntent.getExtras();
        
        // Initialize a String value for our message
        String strMsg = "";
        	    
        // If the bundle contains information in the "build" key
        if (bun.getString("build") != null)
        {
        	strMsg = "Your device is running Android version: " + bun.getString("build");
        }
        // If the bundle contains information in the "ETime" key
        else if (bun.getLong("time") > 0)
        {
        	strMsg = "The emulator has been running for: " + bun.getLong("time") + " milliseconds.";
        }
                
        // Find the TextView control on the screen
        TextView tv = (TextView)findViewById(R.id.secondTextView);
        
        // Set the text to our message String value
        tv.setText(strMsg);
    }
    
}
