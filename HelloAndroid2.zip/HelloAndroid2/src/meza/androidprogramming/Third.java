package meza.androidprogramming;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class Third extends Activity implements OnClickListener
{
	/** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) 
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.third);
        
        // Set the onClickListener for the color buttons
        Button b = (Button)findViewById(R.id.buttonBlue);
        
        b.setOnClickListener(this);
        
    }

    // The onClick() method will be called when a user presses a button
    // on the screen.
	public void onClick(View v) 
	{
		// Create a new Intent to go back to main screen
    	Intent colorIntent = new Intent();	

    	// Get the id value of the control that was clicked
    	int id = v.getId();
		
    	// If the SDK button was clicked
    	if (id == R.id.buttonBlue)
    	{
    		// Add the color blue to the Intent
    		colorIntent.putExtra("color", "blue");
    	}
    	else if (id == R.id.buttonRed)
    	{
    		// Add the color red to the Intent
    		colorIntent.putExtra("color", "red");
    	}
    	
    	// Send the result back to the calling activity
    	setResult(RESULT_OK, colorIntent);
    	
    	// close the current screen
    	finish();
	}
}

