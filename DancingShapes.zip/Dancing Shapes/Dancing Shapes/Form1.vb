﻿Public Class DancingForm

    'This is the array of colors for the square
    Dim squareColorArray() As Color = {Color.Blue, Color.Red, Color.Green, Color.Yellow}

    'This is the array of colors for the circle
    Dim circleColorArray() As Color = {Color.Red, Color.Aqua, Color.Chocolate, Color.Fuchsia}

    Dim currentSquareColor As Integer = 0   'This is the current index for the color of the square
    Dim currentCircleColor As Integer = 0   'This is the current index for the color of the circle



    Private Sub DancingForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
